function varargout = chepai(varargin)
% CHEPAI M-file for chepai.fig
%      CHEPAI, by itself, creates a new CHEPAI or raises the existing
%      singleton*.
%
%      H = CHEPAI returns the handle to a new CHEPAI or the handle to
%      the existing singleton*.
%
%      CHEPAI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CHEPAI.M with the given input arguments.
%
%      CHEPAI('Property','Value',...) creates a new CHEPAI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before chepai_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to chepai_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help chepai

% Last Modified by GUIDE v2.5 10-May-2020 14:05:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @chepai_OpeningFcn, ...
                   'gui_OutputFcn',  @chepai_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before chepai is made visible.
function chepai_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to chepai (see VARARGIN)

% Choose default command line output for chepai
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes chepai wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = chepai_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in find.
function find_Callback(hObject, eventdata, handles)
% hObject    handle to find (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%��ȡͼ��   װ���������ɫͼ����ʾԭʼͼ��
global Scolor
[fn,pn,fi]=uigetfile('*.bmp','ѡ��ͼƬ');
Scolor=imread([pn fn]);
axes(handles.axes1)
imshow(Scolor)


% --- Executes on button press in ok.
function ok_Callback(hObject, eventdata, handles)
% hObject    handle to ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Scolor
axes(handles.axes1);
imshow(Scolor),title('����ԭʼͼ��');
%����ɫͼ��ת��Ϊ�ڰײ���ʾ
Sgray = rgb2gray(Scolor);%rgb2grayת���ɻҶ�ͼ
%figure,imshow(Sgray),title('ԭʼ�ڰ�ͼ��');
%c=histeq(Sgray);
%figure,imshow(c);title('ֱ��ͼ���⻯ͼ��');
s=strel('disk',13);%strei����13
Bgray=imopen(Sgray,s);%��sgray sͼ��
%figure,imshow(Bgray);title('����ͼ��');%�������ͼ��
Egray=imsubtract(Sgray,Bgray);%����ͼ���
%figure,imshow(Egray);title('��ǿ�ڰ�ͼ��');%����ڰ�ͼ��
grd=edge(Egray,'canny',0.09,'both');
%figure,imshow(grd);title('robert���ӱ�Ե���');
se=[1;1;1]; %���ͽṹԪ�� 
I3=imerode(grd,se);    %��ʴͼ��
%figure,imshow(I3),title('��ʴ���Եͼ��');
bg1=imclose(I3,strel('rectangle',[8,18]));%ȡ���ο�ı����㼴ƽ��8,18
%figure,imshow(bg1);title('ͼ�������[5,19]');%����������ͼ��
bg3=imopen(bg1,strel('rectangle',[8,14]));%ȡ���ο�Ŀ�����8,18
%figure,imshow(bg3);title('ͼ������[5,19]');%����������ͼ��
bg2=bwareaopen(bg3,700);%ȥ�����ŻҶ�ֵС��1000�Ĳ���800
%figure,imshow(bg2);title('�Ӷ������Ƴ�С����');
[y,x,]=size(bg2);
I6=double(bg2);
%����������ͼ
Y1=zeros(y,1);%y��1�е������
for i=1:y
        for j=1:x
            if(I6(i,j,1)==1)
                Y1(i,1)= Y1(i,1)+1;
            end
        end
end
% figure();
% subplot(1,3,1);
% plot(0:y-1,Y1),title('�����ػҶ�ֵ�ۼ�'),xlabel('��ֵ'),ylabel('���غ�'); 
[temp, MaxY]=max(Y1);
PY1=MaxY;
while ((Y1(PY1,1)>=50)&&(PY1>1))
	PY1=PY1-7;
end
PY2=MaxY;
while ((Y1(PY2,1)>=50)&&(PY2<y))
	PY2=PY2+7;
end
%����������ͼ
X1=zeros(1,x);
for j=1:x
     for i=PY1:PY2
            if(I6(i,j,1)==1)
                X1(1,j)= X1(1,j)+1;
            end
     end
end
% subplot(1,3,2);
% plot(0:x-1,X1),title('�����ػҶ�ֵ�ۼ�'),xlabel('��ֵ'),ylabel('������');
PX1=1;
while ((X1(1,PX1)<3)&&(PX1<x))
	PX1=PX1+1;
end
PX2=x;
while ((X1(1,PX2)<3)&&(PX2>PX1))
	PX2=PX2-1;
end

DW=Scolor(PY1:PY2,PX1:PX2,:);
axes(handles.axes2);
imshow(DW),title('���ƶ�λͼ��');
msgbox('ʶ�𲿷�˼·����ͨ��ָ��ַ�+ģ��ƥ���ַ�ʶ��ʱ���ϵ��Q2869939756')


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ax1=(handles.axes1);cla(ax1,'reset')
ax2=(handles.axes2);cla(ax2,'reset')
ax3=(handles.axes3);cla(ax3,'reset')
ax4=(handles.axes4);cla(ax4,'reset')
ax5=(handles.axes5);cla(ax5,'reset')
ax6=(handles.axes6);cla(ax6,'reset')
ax7=(handles.axes7);cla(ax7,'reset')
ax8=(handles.axes8);cla(ax8,'reset')
ax9=(handles.axes9');cla(ax9,'reset')
ax10=(handles.axes10);cla(ax10,'reset')
set(handles.edit2,'string',' ');
msgbox('�ĵ���ϸ��������ʶ��ԭ��')
